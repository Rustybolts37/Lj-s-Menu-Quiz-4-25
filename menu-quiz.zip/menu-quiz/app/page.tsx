"use client";
import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { BadgeCheck, Trophy } from "lucide-react";

const questions = [
  {
    question: "What is a listed allergen for the Wedge Salad?",
    options: ["dairy", "seafood", "egg VO", "VO~+"],
    answer: "dairy"
  },
  {
    question: "What is a listed allergen for the Beet and Goat Cheese Salad?",
    options: ["gluten GFO", "nut", "soy", "allergen: dairy"],
    answer: "nut"
  },
  {
    question: "What is a listed allergen for the LJ's House Salad?",
    options: ["VO~+", "seeds", "dairy DFO", "GFO"],
    answer: "GFO"
  },
  {
    question: "What is a listed allergen for the Choux Choux Bread?",
    options: ["dairy VO~", "GFO                           *+", "VO~+", "wheat"],
    answer: "dairy VO~"
  },
  {
    question: "What is a listed allergen for the Charred Broccoli?",
    options: ["egg", "sesame", "cashews", "nut"],
    answer: "egg"
  }
];

export default function MenuQuiz() {
  const [current, setCurrent] = useState(0);
  const [score, setScore] = useState(0);
  const [showScore, setShowScore] = useState(false);

  const handleAnswer = (option) => {
    if (option === questions[current].answer) {
      setScore(score + 1);
    }
    const next = current + 1;
    if (next < questions.length) {
      setCurrent(next);
    } else {
      setShowScore(true);
    }
  };

  return (
    <div className="max-w-3xl mx-auto mt-10 p-4">
      <h1 className="text-3xl font-bold text-center mb-6">🍴 LJ's Menu Quiz</h1>
      {showScore ? (
        <Card className="text-center p-6">
          <CardContent>
            <Trophy className="mx-auto w-12 h-12 text-yellow-500 mb-2" />
            <h2 className="text-2xl font-bold">You scored {score} out of {questions.length}!</h2>
            <p className="text-gray-600 mt-2">Great job testing your menu knowledge.</p>
            <Button className="mt-4" onClick={() => {
              setCurrent(0);
              setScore(0);
              setShowScore(false);
            }}>
              Try Again
            </Button>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold mb-2">
              Question {current + 1} of {questions.length}
            </h3>
            <p className="mb-4 font-medium">{questions[current].question}</p>
            <div className="space-y-2">
              {questions[current].options.map((opt, idx) => (
                <Button key={idx} className="w-full text-left" onClick={() => handleAnswer(opt)}>
                  {opt}
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}